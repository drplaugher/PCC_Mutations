function y = pbnSampleSteadyState(v,m)

% y = pbnSampleSteadyState(v,m) - a random sample from the steady state
%
% This function takes as input a vector v, which represents the 
% stationary distribution of a pbn, and outputs a binary m-by-n matrix y
% consisting of a random sample from v (n is the number of variables in the
% pbn). Positive integer m denotes the number of samples to be drawn.

% Functions used: pmfrnd.m.

% Harri L�hdesm�ki August 29, 2005.

n = round(log2(length(v)));
bits = [n:-1:1];
y = zeros(m,n);

for i=1:m
    x = pmfrnd(v) - 1; % A random number between 0 and 2^n-1.
    y(i,:) = bitget(x,bits);
end % for i=1:m
