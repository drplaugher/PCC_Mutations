function Ehat = bnBootstrap(X,Y,w,k,F,bi,nr)

% Ehat = bnBootstrap(X,Y,w,k,F,bi,nr) - Bootstrap for Boolean Network inference
%
% Function estimates the (possibly weighted) error of all predictor 
% variable (rows in X) combinations for all the target variables (rows in 
% Y) using the basic bootstrap zero estimator. Currently, the predictor 
% function inference (prediction/classification rule) itself is done using 
% the bnBestFit.m function (other functions can be used as well). Note that
% if unity weights (defined in w) are used for all the samples, then the 
% estimated error is equal to the standard error estimate.
%
% INPUT:
% X,Y,w,k,F,bi - See the definition in bnBestFit.m
% nr    - The number of bootstrap samples (iterations).
%
% OUTPUT:
% Ehat  - Estimated error for all predictor variable combinations and for 
%         all target variables. Ehat has size nchoosek(n,k)-by-ni, where n 
%         is the number of predictor variables, k is the number of 
%         variables in the Boolean functions, and ni is the number of 
%         target variables.

% Functions used: bnBestFit, unidrnd

% 20.11.2003 by Harri L�hdesm�ki, modified from bnCrossVal.
% Modified: 24/08/2005 by HL.


% The number of genes and samples.
[n,m] = size(X);

% The number of target nodes.
ni = size(Y,1);

combnum = nchoosek(n,k);
Ehat = zeros(combnum,ni);
indAll = [1:m];

% Count the weights of the non-bootsrap samples.
ws = 0;

%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% The main loop.
%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Repeat the basic bootstrap nr times.
for r=1:nr
    
    % Draw a random bootstrap sample (i.e., with replacement).
    trainind = unidrnd(m,1,m);
    testind = indAll;
    testind(trainind) = [];
    
    % Infer the Boolean functions.
    [Fhat,OptE,Et] = bnBestFit(X(:,trainind),Y(:,trainind),w(trainind),...
        k,F,bi,X(:,testind),Y(:,testind),w(testind));
    
    Ehat = Ehat + Et;
    ws = ws + sum(w(testind));
    
    % Display something...
    %disp([num2str(r),'/',num2str(nr)]);
    
end % for r=1:nr

% Normalize the error.
Ehat = Ehat/(ws);
