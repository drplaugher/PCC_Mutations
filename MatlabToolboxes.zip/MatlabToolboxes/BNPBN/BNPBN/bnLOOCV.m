function Ehat = bnLOOCV(X,Y,w,k,F,bi)

% Ehat = bnLOOCV(X,Y,w,k,F,bi) - LOOCV for Boolean Network inference
%
% Function estimates the (possibly weighted) error of all predictor 
% variable (rows in X) combinations for all the target variables (rows in 
% Y) using the standard leave-one-out cross-validation. Currently, the 
% predictor function inference (prediction/classification rule) itself is 
% done using the  bnBestFit.m function (other functions can be used as 
% well). Note that if unity weights (defined in w) are used for all the 
% samples, then the estimated LOOCV error is equal to the standard error 
% estimate.
%
% INPUT:
% X,Y,w,k,F,bi - See the definition in bnBestFit.m
%
% OUTPUT:
% Ehat  - Estimated error for all predictor variable combinations and for 
%         all target variables. Ehat has size nchoosek(n,k)-by-ni, where n 
%         is the number of predictor variables, k is the number of 
%         variables in the Boolean functions, and ni is the number of 
%         target variables.

% Functions used: bnBestFit

% 24.08.2005 by Harri L�hdesm�ki, modified from bnCrossVal.

% The number of variables and samples.
[n,m] = size(X);

% The number of target variables.
ni = size(Y,1);

combnum = nchoosek(n,k);
Ehat = zeros(combnum,ni);
indAll = [1:m];


%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% The main loop.
%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Run through all the samples.
for i=1:m
    
    % Indices of the current test data.
    trainind = indAll;
    trainind(i) = []; % Current training set.
    testind = i; % Current test set.
    
    % Infer the Boolean functions.
    [Fhat,Ehatr,Et] = bnBestFit(X(:,trainind),Y(:,trainind),w(trainind),...
        k,F,bi,X(:,testind),Y(:,testind),w(testind));
    
    Ehat = Ehat + Et;
    
    % Display something...
    %disp([num2str(i),'/',num2str(m)]);
    
end % for i=1:cvk


% Normalize the error.
Ehat = Ehat/(sum(w));
