function E = pbnTrueErrors(v,F,k)

% E = pbnTrueErrors(v,F,k) - True prediction error for steady-state
%
% Function computes the true prediction error for all the predictors in F
% relative to steady-state distribution v.
%
% INPUT:
% v     - The stationary distribution of a PBN, i.e., f(1) = 
%         Pr{X = 00...00}, f(2) = Pr{X = 00...01}, ..., f(2^n) = 
%         Pr{X = 11...11}. Vector v has length 2^n, where n is the number
%         of nodes in the PBN.
% F     - A 3-D binary matrix of functions for which the true error is 
%         computed. F is assumed to contain a predictor function for all
%         the variables and for all the predictor variable combinations. F
%         has size (2^k)-by-nchoosek(n-1,k)-by-n, where n is the number of 
%         variables in the pbn and k is the number of variables in each 
%         function. F(:,:,i) defines the functions for the i:th variable. 
%         In particular, Fhat(:,j,i) defines the function for the i:th 
%         variable and for the j:th variable combination (the j:th variable
%         combination corresponds to the variables on the j:th row of the 
%         matrix nchoosek([1:i-1,i+1:n],k);). Each column in F(:,:,i) is 
%         interpreted as the columns in, e.g., bnBestFit.m.
%
% OUTPUT:
% E     - A 2-D matrix of the true errors for all the functions in F. E has
%         size nchoosek(n-1,k)-by-n.

% Functions used: margpdf.m, randintex.m

% 01.09.2005 by Harri L�hdesm�ki. Modified from pbnBayesPreds.m

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Define and initialize some variables.
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

n = round(log2(length(v))); % The number of nodes.
kk = size(F,1);
k = round(log2(kk));

combnum = nchoosek(n-1,k); % The number of different variable combinations.

% All variable combinations will be generated in advance. Check that he
% number of combinations is "samll" enough. This will work only for small
% enough PBNs.
if combnum>20000 % Limit the number of possible combinations.
    error('Too many variable combinations...')
end % if combnum>20000

starti = 1;
stopi = combnum;

% Initialize the output matrices.
E = zeros(combnum,n);


%+++++++++++++++++++++++++++++
% The main loop.
%+++++++++++++++++++++++++++++

% Run through all the nodes.
for i=1:n
    
    % Generate all variable combinations in advance. Remove the current
    % node (target node) from the set of predictors.
    IAll = nchoosek([1:i-1,i+1:n],k);
    
    %++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    % Run through all variable combinations.
    %++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    for j=starti:stopi
        
        % The current variable combinations (in lexicographical ordering).
        I = IAll(j,:);
        
        % Compute the corresponding marginal distribution (including
        % the target node itself).
        vv = margpdf(v,[i,I]);
        
        % Compute the true error relative to the (marginal) steady-state
        % distribution.
        E(j,i) = sum(F(:,j,i)'.*vv(1:kk) + (1 - F(:,j,i)').*vv(kk+1:2*kk));
        
    end % for i=starti:stopi
end % for i=1:n

