function [Ehat,Fhat] = bnSteadyStateErrors(eem,X,w,k,F,bi,nr,cvk)

% [Ehat,Fhat] = bnSteadyStateErrors(eem,X,w,k,F,bi,nr,cvk) - Predictor inference
%
% Function estimates the (possibly weighted) prediction/classification 
% error for all the variables (rows in X) using all the predictor variable 
% combinations as predictors (except the variable to be predicted) from 
% steady state data. An optional output Fhat can be used together with the
% Best-Fit/resubstitution method and contains the Best-Fit functions.
%
% INPUT:
% eem        - Error estimation method used in the inference. Note that the
%              estimated errors correspond to the standard error estimates 
%              if w is a constant vector. Different cases:
%               1. The Best Fit (resubstitution) method.
%               2. The leave-one-out cross-validation (LOOCV).
%               3. The general (possibly repeated) cross-validation (CV).
%               4. The basic bootstrap zero error estimator.
%               5. The .632 Bootstrap error estimate.
% X,w,k,F,bi,nr,cvk - See the definition in bnBestFit.m
%
% OUTPUT:
% Ehat       - Estimated error for all predictor variable combinations 
%              (excluding the variable to be predicted) and for all target 
%              variables. Ehat has size nchoosek(n-1,k)-by-n, where n is 
%              the number of predictor variables and k is the number of 
%              variables in the Boolean functions.
% Fhat       - (Optional if eem==1) A 3-D binary matrix of the Best-Fit 
%              functions for all the variables and all the predictor 
%              variable combinations. Fhat has size 
%             (2^k)-by-nchoosek(n-1,k)-by-n.

% Functions used: bnBestFit, bnLOOCV, bnCrossVal, bnBootstrap, and
% bnBootstrap632.

% 24.08.2005 by Harri L�hdesm�ki.

[n,m] = size(X); % The number of nodes and sample.
combnum = nchoosek(n-1,k);
Ehat = zeros(combnum,n);

if isempty(w)==1
    w = ones(1,m);
end

if eem==1 & nargout==2
    Fhat = -ones(2^k,combnum,n);
end


if eem==1
    if nargout==1
        for i=1:n
            [Fhat,Ehatr] = bnBestFit(X([1:i-1,i+1:n],:),X(i,:),w,k,F,bi);
            Ehat(:,i) = Ehatr;
        end
    elseif nargout==2
        for i=1:n
            [Fhatr,Ehatr] = bnBestFit(X([1:i-1,i+1:n],:),X(i,:),w,k,F,bi);
            Ehat(:,i) = Ehatr;
            Fhat(:,:,i) = Fhatr;
        end
    end

elseif eem==2
    for i=1:n
        Ehat(:,i) = bnLOOCV(X([1:i-1,i+1:n],:),X(i,:),w,k,F,bi);
        %disp([num2str(i),'/',num2str(n)]);
    end

elseif eem==3
    for i=1:n
        Ehat(:,i) = bnCrossVal(X([1:i-1,i+1:n],:),X(i,:),w,k,F,bi,cvk,nr);
        %disp([num2str(i),'/',num2str(n)]);
    end

elseif eem==4
    for i=1:n
        Ehat(:,i) = bnBootstrap(X([1:i-1,i+1:n],:),X(i,:),w,k,F,bi,nr);
        disp([num2str(i),'/',num2str(n)]);
    end

elseif eem==5
    for i=1:n
        Ehat(:,i) = bnBootstrap632(X([1:i-1,i+1:n],:),X(i,:),w,k,F,bi,nr);
        %disp([num2str(i),'/',num2str(n)]);
    end
end
