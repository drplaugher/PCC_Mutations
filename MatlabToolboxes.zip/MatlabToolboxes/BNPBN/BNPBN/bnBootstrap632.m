function Ehat = bnBootstrap632(X,Y,w,k,F,bi,nr)

% Ehat = bnBootstrap632(X,Y,w,k,F,bi,nr) - .632 Bootstrap for Boolean Network inference
%
% Function estimates the (possibly weighted) error of all predictor 
% variable (rows in X) combinations for all the target variables (rows in 
% Y) using the .632 bootstrap estimator. Currently, the predictor function
% inference (prediction/classification rule) itself is done using the 
% bnBestFit.m function (other functions can be used as well). Note that if 
% unity weights (defined in w) are used for all the samples, then the 
% estimated error is equal to the standard error estimate.
%
% INPUT:
% X,Y,w,k,F,bi - See the definition in bnBestFit.m
% nr    - The number of bootstrap samples (iterations).
%
% OUTPUT:
% Ehat  - Estimated error for all predictor variable combinations and for 
%         all target variables. Ehat has size nchoosek(n,k)-by-ni, where n 
%         is the number of predictor variables, k is the number of 
%         variables in the Boolean functions, and ni is the number of 
%         target variables.

% Functions used: bnBestFit, bnBootstrap

% 20.11.2003 by Harri L�hdesm�ki, modified from bnCrossVal.
% Modified: 24/08/2005 by HL.


% Compute the resubstitution errors.
[Fhat,OptE] = bnBestFit(X,Y,w,k,F,bi);

% Compute the basic bootstrap zero error estimate.
Ehat = bnBootstrap(X,Y,w,k,F,bi,nr);

Ehat = (1-0.632)*OptE/sum(w) + 0.632*Ehat;
