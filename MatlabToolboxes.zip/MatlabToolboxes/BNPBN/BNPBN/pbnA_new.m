function [A,v] = pbnAvar(F,varF,nf,nv,cij,p)

% [A,v] = pbnA(F,varF,nf,nv,cij,p) - state transition matrix of a PBN
% This function creates the 2^n x 2^n transition matrix A corresponding to
% a PBN. Another optional output argument of the function is the stationary
% distribution v.
% INPUT:
% p     - probability of a gene being randomly perturbed
% Other inputs are defined e.g. in pbnRnd.m

% Thanks for Yrj� Leino (CSC, FINLAND) for providing this fast version of
% pbnA.m.

n = length(nf);       % number of genes
pown=2^n;
A = zeros(pown,pown);
cnf = [0 cumsum(nf)];
b = 2.^[size(varF,1)-1:-1:0]';

if p>0
  ov=ones(1,pown);
  hamdist=zeros(pown,1);
  for j=1:pown,
    jbint(j,:)=bitget(j-1,n:-1:1);
  end;
end;

for st=1:pown,
  pm=zeros(2,n);
  stbin = bitget(st-1,n:-1:1);

  for g=1:n,
    for c=cnf(g)+1:cnf(g+1),

      y = F(stbin(varF(1:nv(c),c))*b(end-nv(c)+1:end)+1,c)+1;
      pm(y,g)=pm(y,g)+cij(c-cnf(g),g);
    end;
  end;
  A(st,:)=sarjatulo(pm(1,:));
  if p>0
     ov(st)=0;
     stbint = repmat(stbin,pown,1);
     hamdist=sum(bitxor(stbint,jbint),2)';
     A(st,:)=(A(st,:)*(1-p)^n)+p.^hamdist.*(1-p).^(n-hamdist).*ov;
     ov(st)=1;
  end;
end;

if nargout == 2
    [v,d] = eig(A');
    [maxeig,idxeig] = max(diag(d));        % largest eigenvalue
    v = v(:,idxeig);
    v = v/sum(v);
end;



%XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX


function tm=sarjatulo(a)

n=length(a);

tm=[a(1) 1-a(1)];

for i=2:n,
  tmvali=zeros(1,2^i);
  ker=a(i);
  cker=1-ker;
  tmvali(1:2:end-1)=tm*ker;
  tmvali(2:2:end)=tm*cker;
  tm=tmvali;
end;
